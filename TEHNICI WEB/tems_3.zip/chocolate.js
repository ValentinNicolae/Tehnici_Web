var integer= prompt("Cata ciocolata mananci pe zi...?");
alert("Intr-un an mananci, " + 365*integer );
alert("Pana la 100 de ani ai nevoie de" + 36500*integer);